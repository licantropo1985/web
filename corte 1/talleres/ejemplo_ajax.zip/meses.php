<?php
header('Content-Type: text/html; charset=ISO-8859-1');
if ($_GET['num']==1)
  echo "<strong>Enero </strong>se deriva de <strong>Ianuarius</strong>, es decir, mes dedicado al viejo dios <em>Jano </em>(posiblemente de origen etrusco), simbolo del Sol y de la Luna y que ten�a dos caras.";
if ($_GET['num']==2)
  echo "<strong>Febrero </strong>era el mes de la purificaci�n, <em>Februus</em>, de <em>Februarius. </em>En su segunda quincena se celebraban las fiestas Lupercales, con solemnes purificaciones de los vivos y conmemoraciones de los difuntos.";
if ($_GET['num']==3)
  echo "<strong>Marzo </strong>estaba dedicado a <em>Marte</em>, el dios de la guerra (el antiguo Ares de los griegos), y en la primitiva Roma el a�o comenzaba precisamente este mes. No debe olvidarse que, seg�n la tradici�n, Marte era el padre de R�mulo, fundador de la ciudad.";
if ($_GET['num']==4)
  echo "<strong>Abril </strong>es el mes en que se abre <em>Aprillis</em>, las fuerzas de la naturaleza para la evoluci�n de los vegetales. Es el mes de la primavera, en la que la potencia gen�rica se abre con mayor intensidad en los hombres y mujeres.";
if ($_GET['num']==5)
  echo "<strong>Mayo </strong>conmemora a <em>Maia</em>, hija de Allante, madre de Mercurio y s�mbolo de la festividad de los cereales.";
if ($_GET['num']==6)
  echo "<strong>Junio</strong> es el mes al que se le atribuyen dos or�genes distintos, seg�n unos descend�a de <em>Juno</em>, la reina del Olimpo, espsa de J�piter (de rotundas formas inmortalizadas por Rubens). Pero seg�n otros el nombre procede de <em>Lucius Iunius Brutus</em>, quien capitane� la revoluci�n que destron� al �ltimo rey de Roma e instaur� la Rep�blica.";
if ($_GET['num']==7)
  echo "<strong>Julio</strong> est� dedicado a <em>Iulius Caesar</em>, nacido de un parto dif�cil provocado por una operaci�n, que a�n se practica y por eso lleva su nombre (aunque debo advertir que esto es falso, pues la palabra ces�rea viene del verbo <em>caedare</em>, cortar, y se ignora c�mo naci� Julio Cesar).";
if ($_GET['num']==8)
  echo "<strong>Agosto </strong>estaba dedicado a Cesar Octavio <em>Augusto</em>, primer emperador de Roma.";
if ($_GET['num']==9)
  echo "<strong>Septiembre </strong>procede de <em>septem</em>, es decir, siete porque era el s�ptimo mes cuando, como he comentado, el a�o empezaba en marzo.";
if ($_GET['num']==10)
  echo "<strong>Octubre, </strong>de <em>octo</em>, ocho.";
if ($_GET['num']==11)
  echo "<strong>Noviembre</strong>, de <em>novem</em>, o sea nueve.";
if ($_GET['num']==12)
  echo "<strong>Diciembre</strong>, de <em>decem</em>, diez, por las mismas razones apuntadas.";
?>